# RayUtil class that always use in code
- - - 