from setuptools import setup

setup(
    name='RayUtil',
    version='0.0.1',
    description='a ',
    license='MIT',
    packages=['RayUtil'],
    author='ray',
    author_email='rayleeafar@gmail.com',
    keywords=['personal use'],
    url='https://github.com/rayleeafar/RayUtil'
)
